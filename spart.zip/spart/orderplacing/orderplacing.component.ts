import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-orderplacing',
  templateUrl: './orderplacing.component.html',
  styleUrls: ['./orderplacing.component.css']
})
export class OrderplacingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
