package com.capstore.service;

import java.util.Date;
import java.util.List;

import com.capstore.d.CartProduct;
import com.capstore.d.Order;
import com.capstore.d.Product;

public interface IOrderService {

	public List<Product> displayCartProducts(int orderId);

	public boolean checkAvailabilityInInventory(Order order);
	public Order placeOrder(Order order);
	public boolean deliverOrderAndUpdateInventory(Order order);
	
	public Order findOrderById(int orderId);
	public boolean deleteOrder(int orderId);
	
	public List<Order> getOrdersForCustomer( int custId);
	
	public List<Order> getOrdersBetween(Date fromDate, Date toDate);
	
	public List<Order> getAllOrders();

	
	
	
}